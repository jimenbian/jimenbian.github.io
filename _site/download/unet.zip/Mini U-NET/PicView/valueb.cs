﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PicView
{
    class valueb
    {
        public double Compute1(int a1,int a2,double a3,int a4)
        { double a5;
        a5 = 69.55 + 26.16 * (Math.Log10(a1)) - 13.82 * (Math.Log10(a2)) - a3 + (44.9 - 6.55 * (Math.Log10(a2))) * (Math.Log10(a4)-3);
        return a5;
        }
    }
}
